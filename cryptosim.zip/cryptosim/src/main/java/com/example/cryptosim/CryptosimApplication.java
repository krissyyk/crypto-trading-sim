package com.example.cryptosim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CryptosimApplication {

	public static void main(String[] args) {
		SpringApplication.run(CryptosimApplication.class, args);
	}

}
